/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { StatusIncident, StatusItem, ScheduledMaintenance, Entity } from './types';
export interface GitHubIssue {
    number: number;
    title: string;
    state: 'open' | 'closed';
    created_at: string;
    updated_at: string;
    closed_at?: string;
    html_url: string;
    body?: string | null;
    labels: Array<{
        name: string;
    }>;
    comments: number;
}
export interface GitHubComment {
    user: {
        login: string;
    };
    created_at: string;
    body: string;
}
export declare class GitHubStatusService {
    private octokit;
    private owner;
    private repo;
    private statusLabel;
    private entities;
    private maintenanceLabels;
    private labelParser;
    constructor(token: string | undefined, owner: string, repo: string, statusLabel: string, entities: Entity[], labelScheme: {
        separator?: string;
        defaultType?: any;
        allowUntyped?: boolean;
    } | undefined, maintenanceLabels?: string[]);
    /**
     * Fetch all status-related issues from GitHub
     */
    fetchStatusIssues(): Promise<GitHubIssue[]>;
    /**
     * Convert GitHub issues to status incidents
     */
    convertIssueToIncident(issue: GitHubIssue): StatusIncident;
    /**
     * Generate status items from incidents
     */
    generateStatusItems(incidents: StatusIncident[]): StatusItem[];
    /**
     * Fetch and process all status data
     */
    fetchStatusData(): Promise<{
        items: StatusItem[];
        incidents: StatusIncident[];
    }>;
    /**
     * Fetch maintenance issues from GitHub
     */
    fetchMaintenanceIssues(): Promise<GitHubIssue[]>;
    /**
     * Fetch comments for an issue
     */
    fetchIssueComments(issueNumber: number): Promise<GitHubComment[]>;
    /**
     * Convert GitHub issue to ScheduledMaintenance
     */
    convertIssueToMaintenance(issue: GitHubIssue): Promise<ScheduledMaintenance | null>;
    /**
     * Fetch all scheduled maintenance
     */
    fetchScheduledMaintenance(): Promise<ScheduledMaintenance[]>;
}
//# sourceMappingURL=github-service.d.ts.map