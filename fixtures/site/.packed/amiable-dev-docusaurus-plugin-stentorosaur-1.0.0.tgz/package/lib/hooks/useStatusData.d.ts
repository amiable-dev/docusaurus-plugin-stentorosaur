/**
 * ADR-001: useStatusData Hook
 *
 * React hook for runtime data fetching based on DataSource configuration.
 * Handles:
 * - Strategy-based URL resolution
 * - Data fetching with loading/error states
 * - Schema validation via Zod
 * - Polling for real-time updates
 * - Cache busting for gist/CDN sources
 *
 * @see docs/adrs/ADR-001-configurable-data-fetching-strategies.md
 */
import type { DataSource } from '../types';
import { ValidatedStatusData } from '../data-source-validator';
/**
 * Options for the useStatusData hook
 */
export interface UseStatusDataOptions {
    /** Data source configuration */
    dataSource: DataSource;
    /** Initial data to show while loading */
    initialData?: ValidatedStatusData;
    /** Whether to enable fetching (default: true) */
    enabled?: boolean;
    /** Polling interval in milliseconds (0 = no polling) */
    pollInterval?: number;
}
/**
 * Return value from the useStatusData hook
 */
export interface UseStatusDataResult {
    /** Fetched and validated status data */
    data: ValidatedStatusData | null;
    /** Whether a fetch is in progress */
    loading: boolean;
    /** Error message if fetch failed */
    error: string | null;
    /** Function to manually trigger a refetch */
    refetch: () => void;
}
/**
 * Custom hook for fetching status data based on DataSource configuration.
 *
 * @param options - Hook options
 * @returns Status data, loading state, error, and refetch function
 *
 * @example
 * ```tsx
 * const { data, loading, error, refetch } = useStatusData({
 *   dataSource: { strategy: 'github', owner: 'my-org', repo: 'my-repo' },
 *   pollInterval: 30000,
 * });
 * ```
 */
export declare function useStatusData(options: UseStatusDataOptions): UseStatusDataResult;
export default useStatusData;
//# sourceMappingURL=useStatusData.d.ts.map