/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { DailySummaryEntry } from '../types';
/**
 * Options for useDailySummary hook
 */
export interface UseDailySummaryOptions {
    /** Base URL for fetching data (e.g., '/status-data') */
    baseUrl: string;
    /** Service name to get data for */
    serviceName: string;
    /** Number of days to return (default: 90) */
    days?: number;
    /** Whether to enable fetching (default: true) */
    enabled?: boolean;
}
/**
 * Result type for useDailySummary hook
 */
export interface UseDailySummaryResult {
    /** Array of daily summary entries (null while loading) */
    data: DailySummaryEntry[] | null;
    /** Whether data is currently being fetched */
    loading: boolean;
    /** Error message if fetch failed */
    error: string | null;
    /** ISO timestamp of last data update */
    lastUpdated: string | null;
}
/**
 * Hook for fetching and merging daily summary data with live data
 */
export declare function useDailySummary(options: UseDailySummaryOptions): UseDailySummaryResult;
//# sourceMappingURL=useDailySummary.d.ts.map