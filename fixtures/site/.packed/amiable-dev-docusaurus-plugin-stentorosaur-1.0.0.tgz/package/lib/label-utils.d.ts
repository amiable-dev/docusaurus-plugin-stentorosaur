/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Label parsing utilities for entity identification
 */
import type { Entity, EntityType, LabelScheme } from './types';
export declare class LabelParser {
    private scheme;
    constructor(scheme?: Partial<LabelScheme>);
    /**
     * Parse GitHub label to extract entity type and name
     *
     * Supports two formats:
     * 1. Namespaced (explicit type): 'system:api', 'process:onboarding'
     * 2. Simple (uses defaultType): 'api', 'onboarding'
     *
     * Examples:
     *   'api' → { type: 'system', name: 'api' } (defaultType='system')
     *   'system:api' → { type: 'system', name: 'api' }
     *   'process:onboarding' → { type: 'process', name: 'onboarding' }
     *   'onboarding' → { type: 'system', name: 'onboarding' } (fallback to defaultType)
     *
     * Simple labels reduce overhead and allow naming collision validation in config.
     */
    parseLabel(label: string): {
        type: EntityType;
        name: string;
    } | null;
    /**
     * Extract entities from GitHub issue labels
     * Returns array of entity identifiers affected by the issue
     */
    extractEntitiesFromLabels(labels: string[], knownEntities: Entity[]): Array<{
        type: EntityType;
        name: string;
    }>;
}
//# sourceMappingURL=label-utils.d.ts.map