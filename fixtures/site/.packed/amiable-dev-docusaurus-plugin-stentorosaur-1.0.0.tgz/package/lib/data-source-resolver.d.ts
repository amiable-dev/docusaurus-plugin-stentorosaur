/**
 * ADR-001: Data Source Resolver
 *
 * Resolves plugin configuration into executable DataSource strategies.
 * Handles:
 * - New dataSource configuration (preferred)
 * - Legacy fetchUrl conversion (deprecated)
 * - URL pattern detection for strategy inference
 *
 * @see docs/adrs/ADR-001-configurable-data-fetching-strategies.md
 */
import type { DataSource, PluginOptions } from './types';
/**
 * Resolve plugin options to a DataSource configuration.
 *
 * Priority:
 * 1. dataSource (new, preferred)
 * 2. fetchUrl (deprecated, with warning)
 * 3. build-only (default)
 *
 * @param options - Plugin options
 * @returns Resolved DataSource configuration
 */
export declare function resolveDataSource(options: Partial<PluginOptions>): DataSource;
/**
 * Build the fetch URL for a given DataSource configuration.
 *
 * @param dataSource - Resolved DataSource configuration
 * @returns URL string for fetching, or null for build-only strategy
 */
export declare function buildFetchUrl(dataSource: DataSource): string | null;
/**
 * Infer DataSource strategy from a URL pattern.
 *
 * Used for legacy fetchUrl conversion. Detects:
 * - raw.githubusercontent.com -> github strategy (with parsed owner/repo/branch)
 * - Everything else -> http strategy
 *
 * @param url - URL to analyze
 * @returns Inferred DataSource configuration
 */
export declare function inferStrategyFromUrl(url: string): DataSource;
//# sourceMappingURL=data-source-resolver.d.ts.map