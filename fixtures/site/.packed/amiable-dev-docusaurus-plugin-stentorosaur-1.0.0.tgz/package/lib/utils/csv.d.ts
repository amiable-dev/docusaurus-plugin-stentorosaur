/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Escapes a value for CSV format
 * - Wraps in quotes if contains comma, quote, or newline
 * - Doubles internal quotes
 */
export declare function escapeCSVValue(value: any): string;
/**
 * Converts an array of objects to CSV format
 *
 * @param data - Array of objects to convert
 * @param columns - Optional array of column names to include (defaults to all keys from first object)
 * @returns CSV string with header row and data rows
 */
export declare function convertToCSV(data: any[], columns?: string[]): string;
/**
 * Triggers a file download in the browser
 *
 * @param content - File content as string
 * @param filename - Name of the file to download
 * @param mimeType - MIME type of the file
 */
export declare function downloadFile(content: string, filename: string, mimeType: string): void;
/**
 * Formats a date for use in filenames (YYYY-MM-DD)
 */
export declare function formatDateForFilename(date: Date | string): string;
/**
 * Sanitizes a string for use in filenames
 * Removes or replaces characters that are invalid in filenames
 */
export declare function sanitizeFilename(name: string): string;
//# sourceMappingURL=csv.d.ts.map