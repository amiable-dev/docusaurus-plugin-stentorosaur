/**
 * Copyright (c) Amiable Development
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Convert markdown to safe HTML
 * @param markdown - Raw markdown string from GitHub Issues
 * @returns Sanitized HTML string safe for rendering
 */
export declare function markdownToHtml(markdown: string | undefined): string;
/**
 * React component for rendering markdown content
 * @param content - Raw markdown string
 * @returns JSX element with rendered HTML
 */
export declare function MarkdownContent({ content }: {
    content: string | undefined;
}): JSX.Element;
//# sourceMappingURL=markdown.d.ts.map