/**
 * StatusDataProvider — v1.0 (ADR-005 §4, ticket #77).
 *
 * The uptime-bar day data now arrives INSIDE the summary the page
 * already holds (compact day tuples per entity), so this provider is a
 * pure derivation over props — no runtime fetching, no loading states.
 * The context shape is kept from ADR-004 so UptimeBar and friends
 * consume it unchanged.
 */
import { type ReactNode } from 'react';
import type { StatusSummary } from '@stentorosaur/core';
/** Day status for UptimeBar visualization. */
export interface DayStatus {
    /** ISO date string (YYYY-MM-DD) */
    date: string;
    /** Uptime percentage (0-100) */
    uptimePercent: number;
    /** Number of incidents (absent in v1 — day rollups carry no counts) */
    incidents?: number;
    /** Total checks performed (absent in v1 — day rollups carry no counts) */
    checksTotal?: number;
    /** Successful checks (absent in v1 — day rollups carry no counts) */
    checksPassed?: number;
    /** Computed status based on uptime thresholds */
    status: 'operational' | 'degraded' | 'outage' | 'no-data';
    /** Average latency in ms (optional) */
    avgLatencyMs?: number | null;
    /** P95 latency in ms (optional) */
    p95LatencyMs?: number | null;
}
export interface StatusDataContextValue {
    /** Truthy once day data is available (always, in v1 — data is in props) */
    dailySummary: {
        source: 'status/v1';
    } | null;
    /** Kept for interface compatibility; v1 has no runtime fetch here */
    currentStatus: null;
    loading: boolean;
    error: Error | null;
    /** Last-N-days statuses for a service, NEWEST first */
    getMerged90Days: (serviceName: string) => DayStatus[];
}
export interface StatusDataProviderProps {
    summary: StatusSummary;
    children: ReactNode;
}
export declare function StatusDataProvider({ summary, children }: StatusDataProviderProps): JSX.Element;
export declare function useStatusData(): StatusDataContextValue;
//# sourceMappingURL=StatusDataProvider.d.ts.map