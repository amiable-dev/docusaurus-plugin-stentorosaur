/**
 * ADR-001: Data Source Validator
 *
 * Provides:
 * - Zod schema validation for fetched status data (Issue #43)
 * - Security validation for data sources (Issue #44)
 *
 * @see docs/adrs/ADR-001-configurable-data-fetching-strategies.md
 */
import { z } from 'zod';
import type { DataSource } from './types';
/**
 * Maximum payload size in bytes (1MB)
 * Prevents DoS from oversized responses
 */
export declare const MAX_PAYLOAD_SIZE = 1000000;
/**
 * Status data schema with size validation
 *
 * Validates:
 * - Required services array
 * - Optional timestamp
 * - Maximum 100 services
 * - Maximum 1MB total payload size
 */
export declare const StatusDataSchema: z.ZodObject<{
    services: z.ZodArray<z.ZodPipe<z.ZodObject<{
        name: z.ZodString;
        status: z.ZodEnum<{
            degraded: "degraded";
            maintenance: "maintenance";
            operational: "operational";
            outage: "outage";
        }>;
        latency: z.ZodOptional<z.ZodNumber>;
        description: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>, z.ZodTransform<{
        latency?: number | undefined;
        name: string;
        status: "degraded" | "maintenance" | "operational" | "outage";
    }, {
        name: string;
        status: "degraded" | "maintenance" | "operational" | "outage";
        latency?: number | undefined;
        description?: string | undefined;
    }>>>;
    timestamp: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
/**
 * Inferred type from StatusDataSchema
 */
export type ValidatedStatusData = z.infer<typeof StatusDataSchema>;
/**
 * Validate status data against the schema.
 *
 * @param data - Raw data to validate
 * @returns Validated and sanitized status data
 * @throws Error if validation fails
 */
export declare function validateStatusData(data: unknown): ValidatedStatusData;
/**
 * Security validation options
 */
export interface SecurityValidationOptions {
    /** Execution context */
    context: 'production' | 'development';
    /** Protocol of the host site (for mixed content detection) */
    siteProtocol?: 'https:' | 'http:';
}
/**
 * Validate data source configuration for security issues.
 *
 * Checks:
 * - HTTPS enforcement in production
 * - Sensitive headers exposure
 * - Mixed content warnings
 *
 * @param dataSource - Data source configuration
 * @param options - Validation options
 */
export declare function validateDataSourceSecurity(dataSource: DataSource, options: SecurityValidationOptions): void;
/**
 * Validate raw JSON response before parsing.
 *
 * @param responseText - Raw response text
 * @returns Parsed and validated status data
 * @throws Error if response is too large or invalid
 */
export declare function validateAndParseResponse(responseText: string): ValidatedStatusData;
//# sourceMappingURL=data-source-validator.d.ts.map