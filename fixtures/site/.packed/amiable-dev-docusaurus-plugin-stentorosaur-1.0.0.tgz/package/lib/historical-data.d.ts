/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { StatusCheckHistory } from './types';
/**
 * Load historical status data from current.json (rolling 14-day window)
 */
export declare function loadHistoricalData(systemName: string, dataPath?: string): Promise<StatusCheckHistory[]>;
/**
 * Aggregate historical data by time period
 */
export declare function aggregateHistoricalData(history: StatusCheckHistory[], periodHours: number): StatusCheckHistory[];
/**
 * Calculate average response time for a time period
 */
export declare function calculateAverageResponseTime(history: StatusCheckHistory[], periodHours?: number): number;
/**
 * Calculate uptime percentage for a time period
 */
export declare function calculateUptimePercentage(history: StatusCheckHistory[], periodHours?: number): number;
/**
 * Calculate daily uptime statistics
 */
export interface DailyUptimeStats {
    date: string;
    uptime: number;
    checks: number;
    upChecks: number;
    avgResponseTime: number;
}
export declare function calculateDailyStats(history: StatusCheckHistory[], days: number): DailyUptimeStats[];
/**
 * Generate sample historical data for demo purposes
 * Uses system name as seed for consistent data across builds
 *
 * @param systemName - Name of the system (used as seed)
 * @param days - Number of days of history to generate
 * @param baseTimestamp - Optional base timestamp (for consistency across calls)
 */
export declare function generateDemoHistory(systemName: string, days?: number, baseTimestamp?: number): StatusCheckHistory[];
//# sourceMappingURL=historical-data.d.ts.map