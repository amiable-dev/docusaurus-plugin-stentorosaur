/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * Calculate resolution time in minutes between created and closed dates
 */
export declare function calculateResolutionTime(createdAt: string, closedAt: string | undefined): number | undefined;
/**
 * Format duration in a human-readable way
 * @param minutes - Duration in minutes
 * @returns Formatted string like "5 minutes", "2 hours", "3 days"
 */
export declare function formatDuration(minutes: number): string;
/**
 * Format resolution info for display
 * @param resolutionMinutes - Time to resolve in minutes
 * @param commentCount - Number of comments/posts
 * @returns Formatted string like "Resolved in 47 minutes with 5 posts"
 */
export declare function formatResolutionInfo(resolutionMinutes: number | undefined, commentCount: number | undefined): string | undefined;
/**
 * Native replacement for date-fns formatDistanceToNow(+addSuffix)
 * (ADR-005 §11: date-fns → Intl). "3 hours ago" / "in 2 days".
 */
export declare function relativeTimeFromNow(date: Date, now?: Date): string;
//# sourceMappingURL=time-utils.d.ts.map