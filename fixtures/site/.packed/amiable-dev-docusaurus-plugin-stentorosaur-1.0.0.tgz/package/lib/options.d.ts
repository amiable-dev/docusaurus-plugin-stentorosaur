/**
 * Plugin option validation — v1.0 (ADR-005 §11). The monitoring config
 * lives in stentorosaur.config.js (consumed by the probe CLI); the
 * plugin options are display concerns plus the data endpoint.
 */
import { Joi } from '@docusaurus/utils-validation';
import type { OptionValidationContext } from '@docusaurus/types';
import type { PluginOptions } from './types';
export declare const DEFAULT_OPTIONS: Partial<PluginOptions>;
export declare const pluginOptionsSchema: Joi.ObjectSchema<PluginOptions>;
export declare function validateOptions({ validate, options, }: OptionValidationContext<PluginOptions, PluginOptions>): PluginOptions;
//# sourceMappingURL=options.d.ts.map