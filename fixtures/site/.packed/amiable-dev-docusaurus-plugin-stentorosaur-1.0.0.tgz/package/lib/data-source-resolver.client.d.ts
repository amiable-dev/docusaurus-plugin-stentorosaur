/**
 * ADR-001: Client-Safe Data Source Resolver
 *
 * This module provides URL building utilities that can be safely imported
 * in browser/client contexts. It does NOT import any Node.js-only modules
 * like @docusaurus/utils-validation.
 *
 * For server-side validation and resolution, use data-source-resolver.ts.
 *
 * @see docs/adrs/ADR-001-configurable-data-fetching-strategies.md
 */
import type { DataSource } from './types';
/**
 * Build the fetch URL for a given DataSource configuration.
 *
 * This is the client-safe version that can be used in browser contexts.
 * It assumes the DataSource has already been validated.
 *
 * @param dataSource - Validated DataSource configuration
 * @returns URL string for fetching, or null for build-only strategy
 */
export declare function buildFetchUrl(dataSource: DataSource): string | null;
//# sourceMappingURL=data-source-resolver.client.d.ts.map