/**
 * Discord notification provider using Webhooks
 */
import type { NotificationEvent } from '../types';
export interface DiscordConfig {
    enabled: boolean;
    webhookUrl: string;
    username?: string;
    avatarUrl?: string;
    retryConfig?: {
        maxRetries: number;
        retryDelayMs: number;
        timeoutMs: number;
    };
}
export declare class DiscordProvider {
    private config;
    readonly name = "discord";
    constructor(config: DiscordConfig);
    send(event: NotificationEvent): Promise<boolean>;
    validate(config: DiscordConfig): void;
    private formatMessage;
    private getColorForEvent;
    private formatDuration;
    private getEventTitle;
    private getEmojiForEvent;
}
//# sourceMappingURL=discord-provider.d.ts.map