/**
 * Telegram notification provider using Bot API
 */
import type { NotificationEvent } from '../types';
export interface TelegramConfig {
    enabled: boolean;
    botToken: string;
    chatId: string;
    parseMode?: 'Markdown' | 'HTML';
    retryConfig?: {
        maxRetries: number;
        retryDelayMs: number;
        timeoutMs: number;
    };
}
export declare class TelegramProvider {
    private config;
    readonly name = "telegram";
    constructor(config: TelegramConfig);
    send(event: NotificationEvent): Promise<boolean>;
    validate(config: TelegramConfig): void;
    private formatMessage;
    private formatUnixTime;
    private getEventTitle;
    private getEmojiForEvent;
    private escapeMarkdown;
    private formatDuration;
}
//# sourceMappingURL=telegram-provider.d.ts.map