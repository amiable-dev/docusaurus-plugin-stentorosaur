/**
 * Email notification provider using SMTP (nodemailer)
 */
import type { NotificationEvent } from '../types';
export interface EmailConfig {
    enabled: boolean;
    provider: 'smtp' | 'sendgrid' | 'ses' | 'mailgun';
    from: string;
    to: string[];
    cc?: string[];
    smtp?: {
        host: string;
        port: number;
        secure: boolean;
        auth: {
            user: string;
            pass: string;
        };
    };
    retryConfig?: {
        maxRetries: number;
        retryDelayMs: number;
        timeoutMs: number;
    };
}
export declare class EmailProvider {
    private config;
    readonly name = "email";
    private transporter?;
    constructor(config: EmailConfig);
    send(event: NotificationEvent): Promise<boolean>;
    validate(config: EmailConfig): void;
    private initializeTransporter;
    private formatMessage;
    private getColorForEvent;
    private getEventTitle;
    private getEmojiForEvent;
    private escapeHtml;
    private formatDuration;
}
//# sourceMappingURL=email-provider.d.ts.map