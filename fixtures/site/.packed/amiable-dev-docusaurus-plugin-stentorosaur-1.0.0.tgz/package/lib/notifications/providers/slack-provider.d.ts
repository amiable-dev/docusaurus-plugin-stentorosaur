/**
 * Slack notification provider using Incoming Webhooks
 */
import type { NotificationEvent } from '../types';
export interface SlackConfig {
    enabled: boolean;
    webhookUrl: string;
    channel?: string;
    mentionUsers?: string[];
    retryConfig?: {
        maxRetries: number;
        retryDelayMs: number;
        timeoutMs: number;
    };
}
export declare class SlackProvider {
    private config;
    readonly name = "slack";
    constructor(config: SlackConfig);
    send(event: NotificationEvent): Promise<boolean>;
    validate(config: SlackConfig): void;
    private formatMessage;
    private getEventUrl;
    private getColorForEvent;
    private getEventTitle;
    private getEmojiForEvent;
    private formatDuration;
}
//# sourceMappingURL=slack-provider.d.ts.map