/**
 * Simplified notification service for sending notifications to multiple channels
 */
import type { NotificationEvent } from './types';
import { type SlackConfig } from './providers/slack-provider';
import { type TelegramConfig } from './providers/telegram-provider';
import { type EmailConfig } from './providers/email-provider';
import { type DiscordConfig } from './providers/discord-provider';
export interface SimpleNotificationConfig {
    enabled?: boolean;
    channels?: {
        slack?: SlackConfig;
        telegram?: TelegramConfig;
        email?: EmailConfig;
        discord?: DiscordConfig;
    };
    events?: {
        incidentOpened?: boolean;
        incidentClosed?: boolean;
        incidentUpdated?: boolean;
        maintenanceScheduled?: boolean;
        maintenanceStarted?: boolean;
        maintenanceCompleted?: boolean;
        systemDegraded?: boolean;
        systemRestored?: boolean;
    };
}
export interface NotificationResult {
    provider: string;
    success: boolean;
    error?: Error;
}
export declare class SimpleNotificationService {
    private config;
    private providers;
    constructor(config: SimpleNotificationConfig);
    private initializeProviders;
    sendNotification(event: NotificationEvent): Promise<NotificationResult[]>;
    sendNotifications(events: NotificationEvent[]): Promise<NotificationResult[]>;
    private sendWithRetry;
    private sleep;
    private isEventEnabled;
}
//# sourceMappingURL=simple-notification-service.d.ts.map