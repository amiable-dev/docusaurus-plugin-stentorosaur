/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { SystemStatusFile, StatusIncident, ScheduledMaintenance } from '../../types';
export interface PerformanceMetricsProps {
    /** System status file with historical data */
    systemFile: SystemStatusFile;
    /** Incidents that may affect this system */
    incidents?: StatusIncident[];
    /** Maintenance windows that may affect this system */
    maintenance?: ScheduledMaintenance[];
    /** Whether to show the metrics (controlled externally) */
    isVisible: boolean;
    /** Callback when close/collapse is requested */
    onClose?: () => void;
    /** Whether demo data is being displayed */
    useDemoData?: boolean;
}
export default function PerformanceMetrics({ systemFile, incidents, maintenance, isVisible, onClose, useDemoData, }: PerformanceMetricsProps): JSX.Element | null;
//# sourceMappingURL=index.d.ts.map