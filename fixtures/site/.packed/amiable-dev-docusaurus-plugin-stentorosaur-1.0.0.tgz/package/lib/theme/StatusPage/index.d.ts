/**
 * StatusPage — v1.0 (ADR-005 §4, tickets #72/#77).
 *
 * Snapshot-first: renders the build-time summary immediately, then
 * refreshes it live via useStatusSummary (SWR + ETag + backoff). All
 * chart drill-down data comes from status/v1/entities/<slug>.json under
 * the same base as the summary endpoint.
 */
import type { StatusData, SystemStatusFile } from '../../types';
export interface Props {
    readonly statusData: StatusData;
}
/**
 * …/summary.json → its directory, where the v1 layout's entities/ lives.
 * Any mount that serves summary.json alongside entities/ works — not
 * just the canonical …/status/v1/ path (Council PR #92 r=1). A dataUrl
 * that is not a summary.json leaves drill-down disabled (undefined).
 */
export declare function deriveV1BaseUrl(dataUrl?: string): string | undefined;
/** Same slug rules the probe uses for entity file names. */
export declare function entitySlug(name: string): string;
/** Entity detail readings → the chart-friendly SystemStatusFile shape. */
export declare function detailToSystemFile(detail: {
    name: string;
    generatedAt: string;
    readings: Array<{
        t: number;
        state: string;
        code: number;
        lat: number;
    }>;
}): SystemStatusFile;
export default function StatusPage({ statusData }: Props): JSX.Element;
//# sourceMappingURL=index.d.ts.map