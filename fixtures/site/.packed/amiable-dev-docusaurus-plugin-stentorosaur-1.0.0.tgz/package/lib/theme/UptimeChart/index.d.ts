/**
 * Copyright (c) Amiable Development
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { ChartAnnotation, ScheduledMaintenance, StatusCheckHistory, StatusIncident } from '../../types';
export interface UptimeChartProps {
    /** System name */
    name: string;
    /** Historical check data */
    history: StatusCheckHistory[];
    /** Incidents affecting this system (deprecated - use annotations instead) */
    incidents?: StatusIncident[];
    /** Maintenance windows affecting this system (deprecated - use annotations instead) */
    maintenance?: ScheduledMaintenance[];
    /** Generic annotations for extensibility (incidents, maintenance, deployments, etc.) */
    annotations?: ChartAnnotation[];
    /** Chart type */
    chartType?: 'bar' | 'heatmap';
    /** Time period to display */
    period?: '24h' | '7d' | '30d' | '90d';
    /** Chart height in pixels */
    height?: number;
    /** Show period selector */
    showPeriodSelector?: boolean;
}
export default function UptimeChart({ name, history, incidents, maintenance, annotations, chartType, period, height, showPeriodSelector, }: UptimeChartProps): JSX.Element;
//# sourceMappingURL=index.d.ts.map