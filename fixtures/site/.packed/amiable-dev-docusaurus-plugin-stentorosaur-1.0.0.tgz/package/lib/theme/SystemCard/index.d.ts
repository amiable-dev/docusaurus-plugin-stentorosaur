/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * ADR-004: SystemCard Compound Component
 *
 * Collapsible system status card with compound component pattern.
 * Includes Header, UptimeBar, Details, Metrics, and Charts sub-components.
 *
 * @see docs/adrs/ADR-004-simplified-status-card-ux.md
 */
import React, { type ReactNode } from 'react';
import { type UptimeBarProps } from '../UptimeBar';
/**
 * Status types
 */
export type SystemStatus = 'up' | 'degraded' | 'down' | 'maintenance';
/**
 * Props for SystemCard component
 */
export interface SystemCardProps {
    /** System identifier */
    name: string;
    /** Display name (optional) */
    displayName?: string;
    /** Current status */
    status: SystemStatus;
    /** Enable expand on click (default: true) */
    expandable?: boolean;
    /** Initial expanded state */
    defaultExpanded?: boolean;
    /** Controlled expanded state */
    expanded?: boolean;
    /** Callback when expanded/collapsed */
    onExpandChange?: (expanded: boolean) => void;
    /** Semantic heading level (default: 3) */
    headingLevel?: 2 | 3 | 4;
    /** Accessibility label for expand button */
    expandButtonLabel?: string;
    /** Compound component children */
    children?: ReactNode;
    /** Optional additional className */
    className?: string;
}
/**
 * SystemCard Component
 *
 * Main container for system status with expand/collapse functionality.
 */
export declare function SystemCard({ name, displayName, status, expandable, defaultExpanded, expanded: controlledExpanded, onExpandChange, headingLevel, expandButtonLabel, children, className, }: SystemCardProps): React.ReactElement;
export declare namespace SystemCard {
    var Header: typeof SystemCardHeader;
    var UptimeBar: typeof SystemCardUptimeBar;
    var Details: typeof SystemCardDetails;
    var Metrics: typeof SystemCardMetrics;
    var Charts: typeof SystemCardCharts;
}
/**
 * SystemCard.Header - Custom header content
 */
export interface SystemCardHeaderProps {
    children?: ReactNode;
}
export declare function SystemCardHeader({ children, }: SystemCardHeaderProps): React.ReactElement;
/**
 * SystemCard.UptimeBar - Embedded UptimeBar
 */
export declare function SystemCardUptimeBar(props: Omit<UptimeBarProps, 'serviceName'> & {
    serviceName?: string;
}): React.ReactElement;
/**
 * SystemCard.Details - Expandable content container
 */
export interface SystemCardDetailsProps {
    children?: ReactNode;
}
export declare function SystemCardDetails({ children, }: SystemCardDetailsProps): React.ReactElement;
/**
 * SystemCard.Metrics - Response time and last checked
 */
export interface SystemCardMetricsProps {
    responseTime?: number;
    lastChecked?: string;
}
export declare function SystemCardMetrics({ responseTime, lastChecked, }: SystemCardMetricsProps): React.ReactElement;
/**
 * SystemCard.Charts - Chart container (placeholder)
 */
export interface SystemCardChartsProps {
    serviceName?: string;
    children?: ReactNode;
}
export declare function SystemCardCharts({ children, }: SystemCardChartsProps): React.ReactElement;
export default SystemCard;
//# sourceMappingURL=index.d.ts.map