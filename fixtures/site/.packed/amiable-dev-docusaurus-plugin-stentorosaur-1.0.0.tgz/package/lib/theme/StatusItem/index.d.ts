/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { StatusItem as StatusItemType, StatusIncident, ScheduledMaintenance } from '../../types';
export interface Props {
    item: StatusItemType;
    incidents?: StatusIncident[];
    maintenance?: ScheduledMaintenance[];
    showResponseTime?: boolean;
    showUptime?: boolean;
    showMiniChart?: boolean;
    onClick?: () => void;
    /** Base URL for fetching daily-summary.json (enables 90-day heatmap) */
    dataBaseUrl?: string;
    /** Number of days to show in heatmap (default: 14, or 90 if dataBaseUrl provided) */
    heatmapDays?: number;
}
export default function StatusItem({ item, incidents, maintenance, showResponseTime, showUptime, showMiniChart, onClick, dataBaseUrl, heatmapDays, }: Props): JSX.Element;
//# sourceMappingURL=index.d.ts.map