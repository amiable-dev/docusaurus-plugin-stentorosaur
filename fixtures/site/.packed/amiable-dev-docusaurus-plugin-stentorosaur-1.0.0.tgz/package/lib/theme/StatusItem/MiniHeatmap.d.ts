/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { StatusCheckHistory, StatusIncident, ScheduledMaintenance } from '../../types';
export interface MiniHeatmapProps {
    /** Historical check data */
    history: StatusCheckHistory[];
    /** Incidents to display */
    incidents?: StatusIncident[];
    /** Maintenance windows to display */
    maintenance?: ScheduledMaintenance[];
    /** System name to filter incidents and maintenance */
    systemName?: string;
    /** Number of days to show (default 14, expandable to 90 with daily-summary.json) */
    days?: number;
}
/**
 * Compact heatmap visualization showing daily uptime status
 * Similar to status.claude.com or GitHub contribution graph
 */
export default function MiniHeatmap({ history, incidents, maintenance, systemName, days, }: MiniHeatmapProps): JSX.Element;
//# sourceMappingURL=MiniHeatmap.d.ts.map