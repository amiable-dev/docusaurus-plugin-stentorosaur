/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
export interface Props {
    readonly dataPath?: string;
}
export default function StatusHistory({ dataPath, }?: Props): JSX.Element;
//# sourceMappingURL=index.d.ts.map