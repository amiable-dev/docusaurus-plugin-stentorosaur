/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { StatusItem as StatusItemType, StatusIncident, ScheduledMaintenance } from '../../types';
export interface Props {
    items: StatusItemType[];
    incidents?: StatusIncident[];
    maintenance?: ScheduledMaintenance[];
    title?: string;
    description?: string;
    onSystemClick?: (systemName: string) => void;
    hasSystemData?: (systemName: string) => boolean;
}
export default function StatusBoard({ items, incidents, maintenance, title, description, onSystemClick, hasSystemData, }: Props): JSX.Element;
//# sourceMappingURL=index.d.ts.map