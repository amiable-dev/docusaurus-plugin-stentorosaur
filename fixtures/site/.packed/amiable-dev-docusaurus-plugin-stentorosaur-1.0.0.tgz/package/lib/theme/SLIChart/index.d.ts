/**
 * Copyright (c) Amiable Development
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { StatusCheckHistory } from '../../types';
export interface SLIChartProps {
    /** System name */
    name: string;
    /** Historical check data */
    history: StatusCheckHistory[];
    /** Time period to display */
    period?: '24h' | '7d' | '30d' | '90d';
    /** Chart height in pixels */
    height?: number;
    /** Show time period selector */
    showPeriodSelector?: boolean;
    /** Show error budget instead of SLI compliance */
    showErrorBudget?: boolean;
    /** SLO target (default 99.9%) */
    sloTarget?: number;
}
export default function SLIChart({ name, history, period, height, showPeriodSelector, showErrorBudget, sloTarget, }: SLIChartProps): JSX.Element;
//# sourceMappingURL=index.d.ts.map