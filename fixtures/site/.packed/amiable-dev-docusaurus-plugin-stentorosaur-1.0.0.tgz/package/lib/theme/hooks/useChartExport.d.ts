/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { Chart } from 'chart.js';
export interface UseChartExportReturn {
    /** Export chart as PNG */
    exportPNG: (chart: Chart | null, filename: string) => void;
    /** Export chart as JPEG */
    exportJPEG: (chart: Chart | null, filename: string) => void;
    /** Copy chart to clipboard as PNG */
    copyToClipboard: (chart: Chart | null) => Promise<void>;
}
/**
 * Hook for exporting Chart.js charts in various formats
 */
export declare function useChartExport(): UseChartExportReturn;
//# sourceMappingURL=useChartExport.d.ts.map