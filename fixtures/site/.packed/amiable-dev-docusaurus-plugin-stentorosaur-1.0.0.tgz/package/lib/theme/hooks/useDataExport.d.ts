/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
export type DataExportFormat = 'csv' | 'json';
export interface DataExportOptions {
    /**
     * Name of the file to download (without extension)
     */
    filename: string;
    /**
     * Format to export the data in
     */
    format: DataExportFormat;
    /**
     * Array of data objects to export
     */
    data: any[];
    /**
     * Optional array of column names to include in CSV export
     * If not provided, all keys from the first object will be used
     */
    columns?: string[];
}
/**
 * Hook for exporting chart data in various formats
 *
 * @returns Object containing exportData function
 *
 * @example
 * ```tsx
 * const { exportData } = useDataExport();
 *
 * const handleExport = () => {
 *   exportData({
 *     filename: 'response-time-data',
 *     format: 'csv',
 *     data: chartData,
 *     columns: ['timestamp', 'responseTime', 'status']
 *   });
 * };
 * ```
 */
export declare function useDataExport(): {
    exportData: (options: DataExportOptions) => void;
};
//# sourceMappingURL=useDataExport.d.ts.map