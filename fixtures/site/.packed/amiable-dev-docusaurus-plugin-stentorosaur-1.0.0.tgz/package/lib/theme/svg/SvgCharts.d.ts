/**
 * Shared SVG chart primitives (ADR-005 §11; epic #63 ticket #73).
 *
 * Replaces chart.js/react-chartjs-2 for the plugin's status charts:
 * pure SVG, themed via CSS variables (no MutationObserver), accessible
 * (role="img" + aria-label + per-mark <title> tooltips), and rendered
 * identically under SSR/jsdom (no canvas).
 */
export interface LinePoint {
    label: string;
    value: number | null;
    /** Optional per-point tone (e.g. status coloring) */
    tone?: 'ok' | 'warn' | 'bad';
    /** Tooltip text; defaults to `${label}: ${value}` */
    title?: string;
}
export interface Threshold {
    value: number;
    label: string;
}
export interface SvgLineChartProps {
    points: LinePoint[];
    height?: number;
    /** Y domain; defaults to data extent padded 10% */
    yMin?: number;
    yMax?: number;
    yFormat?: (v: number) => string;
    thresholds?: Threshold[];
    ariaLabel: string;
    /** Show the filled area under the line */
    area?: boolean;
}
export declare function SvgLineChart({ points, height, yMin, yMax, yFormat, thresholds, ariaLabel, area, }: SvgLineChartProps): JSX.Element;
export interface UptimeBarDatum {
    label: string;
    /** 0-100, or null for no data */
    uptime: number | null;
    title?: string;
}
export interface SvgUptimeBarsProps {
    bars: UptimeBarDatum[];
    height?: number;
    ariaLabel: string;
}
export declare function SvgUptimeBars({ bars, height, ariaLabel }: SvgUptimeBarsProps): JSX.Element;
//# sourceMappingURL=SvgCharts.d.ts.map