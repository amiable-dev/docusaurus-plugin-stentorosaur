/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * ADR-004: SystemCardGroup Component
 *
 * Container for grouping multiple SystemCards with collapsible behavior.
 * Shows aggregate status (worst-of) for the group.
 *
 * @see docs/adrs/ADR-004-simplified-status-card-ux.md
 */
import React, { type ReactNode } from 'react';
/**
 * Status types (matching SystemCard)
 */
export type GroupStatus = 'up' | 'degraded' | 'down' | 'maintenance';
/**
 * Props for SystemCardGroup component
 */
export interface SystemCardGroupProps {
    /** Group identifier */
    name: string;
    /** Display name */
    displayName: string;
    /** Initially collapsed (default: false) */
    defaultCollapsed?: boolean;
    /** Group status override (derived from children if not provided) */
    status?: GroupStatus;
    /** Semantic heading level (default: 2) */
    headingLevel?: 2 | 3 | 4;
    /** Children (SystemCard components) */
    children: ReactNode;
    /** Optional additional className */
    className?: string;
}
/**
 * SystemCardGroup Component
 *
 * Groups multiple SystemCards together with a collapsible header.
 * Displays aggregate status based on worst child status.
 */
export declare function SystemCardGroup({ name, displayName, defaultCollapsed, status: explicitStatus, headingLevel, children, className, }: SystemCardGroupProps): React.ReactElement;
export default SystemCardGroup;
//# sourceMappingURL=index.d.ts.map