/**
 * UptimeStatusPage — Upptime-style structured layout, v1.0 (ADR-005).
 *
 * Snapshot-first render from the build-time summary, live refresh via
 * useStatusSummary, and per-entity chart data fetched lazily from
 * status/v1/entities/<slug>.json (same base as the summary endpoint).
 */
import type { StatusData } from '../../types';
export interface Props {
    readonly statusData: StatusData;
}
export default function UptimeStatusPage({ statusData }: Props): JSX.Element;
//# sourceMappingURL=index.d.ts.map