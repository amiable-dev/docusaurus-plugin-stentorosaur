/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * ADR-004: UptimeBar Component
 *
 * 90-day horizontal uptime bar visualization.
 * Displays daily uptime status as colored cells.
 *
 * @see docs/adrs/ADR-004-simplified-status-card-ux.md
 */
import React from 'react';
import { type DayStatus } from '../../context/StatusDataProvider';
/**
 * Custom thresholds for status determination
 */
export interface UptimeThresholds {
    /** Uptime >= this is operational (default: 99) */
    operational: number;
    /** Uptime >= this is degraded, < is outage (default: 95) */
    degraded: number;
}
/**
 * Props for UptimeBar component
 */
export interface UptimeBarProps {
    /** Service name for data lookup (uses context) */
    serviceName: string;
    /** Override data for testing/Storybook */
    data?: DayStatus[];
    /** Number of days to display (default: 90) */
    days?: number;
    /** Height of the bar in pixels (default: 34) */
    height?: number;
    /** Gap between bars in pixels (default: 2) */
    gap?: number;
    /** Show uptime percentage text (default: true) */
    showPercentage?: boolean;
    /** Show date labels (default: true) */
    showDateLabels?: boolean;
    /** Customizable thresholds */
    thresholds?: UptimeThresholds;
    /** Loading state */
    loading?: boolean;
    /** Error state */
    error?: Error | null;
    /** Retry callback */
    onRetry?: () => void;
    /** Accessibility label */
    ariaLabel?: string;
    /** Interaction callbacks */
    onDayClick?: (date: string, status: DayStatus) => void;
    onDayHover?: (date: string, status: DayStatus | null) => void;
    /** Optional additional className */
    className?: string;
}
/**
 * UptimeBar Component
 *
 * Displays a horizontal bar of daily uptime status cells.
 * Each cell represents one day, colored by uptime percentage.
 */
export declare function UptimeBar({ serviceName, data: providedData, days, height, gap, showPercentage, showDateLabels, thresholds, loading, error, onRetry, ariaLabel, onDayClick, onDayHover, className, }: UptimeBarProps): React.ReactElement;
export default UptimeBar;
export type { DayStatus };
//# sourceMappingURL=index.d.ts.map