import type { ScheduledMaintenance } from '../../../types';
interface MaintenanceItemProps {
    maintenance: ScheduledMaintenance;
    showComments?: boolean;
    showAffectedSystems?: boolean;
}
export default function MaintenanceItem({ maintenance, showComments, showAffectedSystems, }: MaintenanceItemProps): JSX.Element;
export {};
//# sourceMappingURL=index.d.ts.map