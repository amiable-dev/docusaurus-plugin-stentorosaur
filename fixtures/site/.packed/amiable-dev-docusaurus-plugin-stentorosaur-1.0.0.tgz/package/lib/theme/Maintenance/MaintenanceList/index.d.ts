import type { ScheduledMaintenance } from '../../../types';
interface MaintenanceListProps {
    maintenance: ScheduledMaintenance[];
    filterStatus?: 'upcoming' | 'in-progress' | 'completed' | 'all';
    showComments?: boolean;
    showAffectedSystems?: boolean;
    emptyMessage?: string;
}
export default function MaintenanceList({ maintenance, filterStatus, showComments, showAffectedSystems, emptyMessage, }: MaintenanceListProps): JSX.Element;
export {};
//# sourceMappingURL=index.d.ts.map