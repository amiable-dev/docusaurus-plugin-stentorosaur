/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
export interface ChartPanelProps {
    /** System name to load data for */
    systemName: string;
    /** Which charts to show */
    charts?: ('response' | 'uptime' | 'sli' | 'error-budget')[];
    /** Default time period */
    period?: '24h' | '7d' | '30d' | '90d';
    /** Layout: horizontal (side-by-side) or vertical (stacked) */
    layout?: 'horizontal' | 'vertical';
    /** Show period selector */
    showPeriodSelector?: boolean;
    /** Chart height */
    height?: number;
    /** Path to status data */
    dataPath?: string;
}
/**
 * Embeddable chart panel component that can be used in any Docusaurus page
 * to display performance metrics for a specific system.
 *
 * @example
 * ```tsx
 * import ChartPanel from '@theme/ChartPanel';
 *
 * <ChartPanel
 *   systemName="Main Website"
 *   charts={['response', 'uptime']}
 *   layout="horizontal"
 * />
 * ```
 */
export default function ChartPanel({ systemName, charts, period, layout, showPeriodSelector, height, dataPath, }: ChartPanelProps): JSX.Element;
//# sourceMappingURL=index.d.ts.map