/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
/**
 * ADR-004: StatusBadge Component
 *
 * Status indicator badge with status text and icon.
 * Supports i18n via customizable labels and size variants.
 *
 * @see docs/adrs/ADR-004-simplified-status-card-ux.md
 */
import React from 'react';
/**
 * Status types supported by the badge
 */
export type StatusType = 'up' | 'degraded' | 'down' | 'maintenance';
/**
 * Custom labels for i18n support
 */
export interface StatusLabels {
    up?: string;
    degraded?: string;
    down?: string;
    maintenance?: string;
}
/**
 * Size variants
 */
export type StatusBadgeSize = 'sm' | 'md' | 'lg';
/**
 * Props for StatusBadge component
 */
export interface StatusBadgeProps {
    /** Current status */
    status: StatusType;
    /** Custom labels for i18n */
    labels?: StatusLabels;
    /** Size variant (default: 'md') */
    size?: StatusBadgeSize;
    /** Optional additional className */
    className?: string;
}
/**
 * StatusBadge Component
 *
 * Displays a status indicator with colored dot and label text.
 * Designed for accessibility with ARIA role and visual icon.
 */
export declare function StatusBadge({ status, labels, size, className, }: StatusBadgeProps): React.ReactElement;
export default StatusBadge;
//# sourceMappingURL=index.d.ts.map