/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { DataExportFormat } from '../hooks/useDataExport';
export interface ExportButtonProps {
    /**
     * Name of the file to download (without extension)
     */
    filename: string;
    /**
     * Array of data objects to export
     */
    data: any[];
    /**
     * Optional array of column names to include in CSV export
     */
    columns?: string[];
    /**
     * Export format (csv or json)
     */
    format?: DataExportFormat;
    /**
     * Optional CSS class name
     */
    className?: string;
    /**
     * Optional accessible label
     */
    ariaLabel?: string;
}
/**
 * Button component for exporting chart data
 *
 * @example
 * ```tsx
 * <ExportButton
 *   filename="response-time-data"
 *   data={chartData}
 *   columns={['timestamp', 'responseTime', 'status']}
 *   format="csv"
 *   ariaLabel="Download response time data as CSV"
 * />
 * ```
 */
export declare function ExportButton({ filename, data, columns, format, className, ariaLabel, }: ExportButtonProps): JSX.Element;
//# sourceMappingURL=ExportButton.d.ts.map