/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { StatusIncident } from '../../types';
export interface Props {
    incidents: StatusIncident[];
    maxItems?: number;
    useDemoData?: boolean;
    title?: string;
}
export default function IncidentHistory({ incidents, maxItems, useDemoData, title, }: Props): JSX.Element;
//# sourceMappingURL=index.d.ts.map