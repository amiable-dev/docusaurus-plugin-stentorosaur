/**
 * Copyright (c) Amiable Development
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { StatusCheckHistory } from '../../types';
export interface ResponseTimeChartProps {
    /** System name */
    name: string;
    /** Historical check data */
    history: StatusCheckHistory[];
    /** Time period to display */
    period?: '24h' | '7d' | '30d' | '90d';
    /** Chart height in pixels */
    height?: number;
    /** Show time period selector */
    showPeriodSelector?: boolean;
}
export default function ResponseTimeChart({ name, history, period, height, showPeriodSelector, }: ResponseTimeChartProps): JSX.Element;
//# sourceMappingURL=index.d.ts.map