/**
 * docusaurus-plugin-stentorosaur — status dashboards for Docusaurus.
 *
 * v1.0 (ADR-005): ONE read path. The plugin reads `status/v1/summary.json`
 * — from `dataUrl` at build time, or from a local checkout under
 * `dataPath` — validates it against the versioned schema, and registers
 * the route. All monitoring, GitHub-issue sync, and data-branch writes
 * live in @stentorosaur/probe (the `stentorosaur` CLI); all transforms
 * live in @stentorosaur/core. loadContent is read + validate + register.
 */
import type { LoadContext, Plugin } from '@docusaurus/types';
import type { PluginOptions, StatusData } from './types';
export { validateOptions } from './options';
export declare function getSwizzleComponentList(): string[];
export default function pluginStatus(context: LoadContext, options: PluginOptions): Promise<Plugin<StatusData>>;
export { type PluginOptions } from './types';
//# sourceMappingURL=index.d.ts.map