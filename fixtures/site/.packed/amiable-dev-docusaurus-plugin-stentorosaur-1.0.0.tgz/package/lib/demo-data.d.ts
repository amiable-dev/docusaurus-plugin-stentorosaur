/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { StatusItem, StatusIncident, SystemStatusFile, ScheduledMaintenance } from './types';
export declare function getDemoStatusData(): {
    items: StatusItem[];
    incidents: StatusIncident[];
    maintenance: ScheduledMaintenance[];
};
/**
 * Get demo system status files with historical data
 */
export declare function getDemoSystemFiles(): SystemStatusFile[];
/**
 * Generate demo data in current.json format (compact readings)
 * This matches the format used by the monitoring script
 */
export declare function getDemoCurrentJson(): {
    version: string;
    generated: number;
    readings: Array<{
        t: number;
        svc: string;
        state: 'up' | 'down' | 'degraded' | 'maintenance';
        code: number;
        lat: number;
        err?: string;
    }>;
};
//# sourceMappingURL=demo-data.d.ts.map