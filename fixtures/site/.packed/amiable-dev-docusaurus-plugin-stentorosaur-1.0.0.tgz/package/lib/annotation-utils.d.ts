/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { ChartAnnotation, StatusIncident, ScheduledMaintenance } from './types';
/**
 * Convert a StatusIncident to a ChartAnnotation
 */
export declare function incidentToAnnotation(incident: StatusIncident): ChartAnnotation;
/**
 * Convert a ScheduledMaintenance to a ChartAnnotation
 */
export declare function maintenanceToAnnotation(maintenance: ScheduledMaintenance): ChartAnnotation;
/**
 * Convert arrays of incidents and maintenance to annotations
 * @param incidents Array of incidents
 * @param maintenance Array of maintenance windows
 * @returns Combined array of annotations sorted by timestamp (newest first)
 */
export declare function createAnnotations(incidents?: StatusIncident[], maintenance?: ScheduledMaintenance[]): ChartAnnotation[];
/**
 * Filter annotations by affected system
 * @param annotations Array of annotations
 * @param systemName Name of the system to filter by
 * @returns Filtered annotations that affect the specified system
 */
export declare function filterAnnotationsBySystem(annotations: ChartAnnotation[], systemName: string): ChartAnnotation[];
//# sourceMappingURL=annotation-utils.d.ts.map