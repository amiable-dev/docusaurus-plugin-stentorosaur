/**
 * Copyright (c) Your Organization
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
import type { ScheduledMaintenance, MaintenanceComment } from './types';
interface MaintenanceFrontmatter {
    type?: string;
    start?: string;
    end?: string;
    systems?: string[];
}
/**
 * Parse human-friendly date strings to ISO 8601
 * Supports:
 * - ISO 8601: "2025-11-15T02:00:00Z"
 * - Friendly: "@tomorrow 2am UTC", "@today 14:30", "tomorrow at 2pm"
 * - Relative: "+2h", "+30m", "in 3 hours"
 *
 * @param dateStr - Date string to parse
 * @param referenceDate - Reference date for relative parsing (default: now)
 * @returns ISO 8601 string or null if unparseable
 */
export declare function parseHumanDate(dateStr: string, referenceDate?: Date): string | null;
/**
 * Extract YAML frontmatter from issue body
 * Skips GitHub issue form headings (###) that appear before frontmatter
 */
export declare function extractFrontmatter(body: string): {
    frontmatter: MaintenanceFrontmatter;
    content: string;
};
/**
 * Determine maintenance status based on start/end times
 */
export declare function getMaintenanceStatus(start: string, end: string, issueState: 'open' | 'closed'): ScheduledMaintenance['status'];
/**
 * Parse GitHub issue comments into maintenance comments
 */
export declare function parseMaintenanceComments(comments: Array<{
    author: {
        login: string;
    };
    created_at: string;
    body: string;
}>): MaintenanceComment[];
/**
 * Check if an issue is a scheduled maintenance based on labels
 */
export declare function isScheduledMaintenance(labels: string[], maintenanceLabels?: string[]): boolean;
/**
 * Format a date string in a specific timezone
 * @param isoDate - ISO 8601 date string (e.g., "2025-01-12T02:00:00Z")
 * @param timezone - Timezone string (e.g., "UTC", "America/New_York", "local")
 * @returns Formatted date string
 */
export declare function formatDateInTimezone(isoDate: string, timezone?: string): string;
/**
 * Get a short, human-friendly date format for display
 * @param isoDate - ISO 8601 date string
 * @param timezone - Optional timezone
 * @returns Short formatted date (e.g., "Jan 12, 2025 2:00 AM")
 */
export declare function formatShortDate(isoDate: string, timezone?: string): string;
export {};
//# sourceMappingURL=maintenance-utils.d.ts.map