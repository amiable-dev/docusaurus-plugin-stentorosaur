/**
 * status/v1 → render-shape adapter (ADR-005; tickets #72/#77).
 *
 * loadContent parses summary.json and adapts it to the StatusData shape
 * the theme components consume. Pure and deterministic. Since the #77
 * cutover this is the ONLY way StatusData is produced.
 */
import type { StatusSummary } from '@stentorosaur/core';
import type { EntityDisplay, StatusData } from '../types';
export interface AdapterOptions {
    /** e.g. https://github.com/owner/repo — used to reconstruct issue URLs */
    repoUrl: string;
    /** Display metadata from plugin options, keyed by entity name */
    entityDisplay?: EntityDisplay[];
}
export declare function summaryToStatusData(summary: StatusSummary, options: AdapterOptions): StatusData;
//# sourceMappingURL=summary-adapter.d.ts.map