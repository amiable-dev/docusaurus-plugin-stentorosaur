/**
 * THE client data hook (ADR-005 §4; epic #63 ticket #72).
 *
 * Implements the mandated fetch protocol:
 *  1. Render immediately from the SSG snapshot (stale-while-revalidate) —
 *     the page is never blank and never shows a loading skeleton.
 *  2. Background fetch with If-None-Match; 200 → validate + swap,
 *     304/invalid → keep current state.
 *  3. Failures: exponential backoff with full jitter (base 30s, cap
 *     15min); 429/403 pauses for the Retry-After window. The status page
 *     never hard-fails because the data plane is unreachable.
 *  4. Refetch on tab focus and on a timer no faster than the serving
 *     cache TTL (default 5 min).
 *  5. Responses parsed as JSON regardless of Content-Type (the
 *     raw.githubusercontent fallback serves text/plain).
 *
 * No dataUrl (e.g. private repos, ADR-005 §9) → pure snapshot mode.
 */
import type { StatusSummary } from '@stentorosaur/core';
export interface UseStatusSummaryOptions {
    /** Build-time snapshot embedded by loadContent — always present */
    snapshot: StatusSummary;
    /** Public summary.json endpoint; absent → snapshot-only mode */
    dataUrl?: string;
    /** Refresh cadence (min-clamped to the default TTL) */
    refreshMs?: number;
    /** Injected for deterministic tests */
    jitter?: () => number;
    /** Test seams — production always uses the §4 constants */
    backoffBaseMs?: number;
    backoffCapMs?: number;
}
export interface UseStatusSummaryResult {
    summary: StatusSummary;
    source: 'snapshot' | 'live';
    /** Non-fatal diagnostics for debugging panels; never blocks rendering */
    lastError: string | null;
}
export declare function useStatusSummary(options: UseStatusSummaryOptions): UseStatusSummaryResult;
//# sourceMappingURL=useStatusSummary.d.ts.map