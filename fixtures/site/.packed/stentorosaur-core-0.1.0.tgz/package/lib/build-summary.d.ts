/**
 * buildSummary — THE deterministic aggregation from probe/issue inputs to
 * status/v1 summary.json (ADR-005 §2, §5).
 *
 * Referential transparency is load-bearing: the regenerate-and-retry
 * concurrency rule (§5) depends on any writer being able to rebuild an
 * identical summary from the same merged inputs. Therefore: no clock
 * reads, no randomness, and all internal ordering is derived from the
 * inputs (entity order is config-owned; readings are sorted internally).
 */
import type { DayRollup, StatusIncidentV1, MaintenanceWindowV1, StatusSummary } from './status-v1';
import type { EntityRef } from './labels';
import type { CompactReading } from './types';
export interface BuildSummaryInputs {
    /** ISO timestamp — injected, never read from the clock */
    generatedAt: string;
    /** e.g. "probe@0.22.0" */
    generatedBy: string;
    /** Config-ordered entities (order is preserved in the output) */
    entities: EntityRef[];
    /** Recent compact readings (the current.json window) */
    readings: CompactReading[];
    /** Per-entity daily rollups, oldest→newest (from archives/daily summary) */
    dailyRollups: Record<string, DayRollup[]>;
    /** All transformed incidents (open and resolved) */
    incidents: StatusIncidentV1[];
    /** All transformed maintenance windows */
    maintenance: MaintenanceWindowV1[];
    /** How many resolved incidents to keep under incidents.recent */
    recentIncidentLimit?: number;
}
/**
 * Derive per-entity daily rollups from raw readings (typically the
 * archive window). Days are UTC; rollups are oldest→newest. The
 * DayAggregate→DayRollup mapping mirrors the summary encoding:
 * uptime% = fraction×100, worst = the worst state observed that day.
 */
export declare function buildDailyRollups(readings: CompactReading[]): Record<string, DayRollup[]>;
export declare function buildSummary(inputs: BuildSummaryInputs): StatusSummary;
//# sourceMappingURL=build-summary.d.ts.map