/**
 * status/v1 — the single canonical data contract (ADR-005 §2).
 *
 * Everything the data branch serves is validated against these schemas on
 * write AND read. `schemaVersion` gates major migrations: minor additive
 * fields are tolerated (unknown keys are stripped, never fatal), while an
 * unknown major version fails loudly with an actionable message.
 *
 * File layout on the data branch:
 *   status/v1/summary.json          — parseSummary (the client's one fetch)
 *   status/v1/entities/<name>.json  — parseEntityDetail (on card expand)
 *   status/v1/raw/<issue>.json      — parseRawIncidentBody (provenance for
 *                                     re-rendering after sanitizer CVEs, §7)
 */
import { z } from 'zod';
export declare const STATUS_SCHEMA_VERSION = 1;
/** Entity/reading state — matches CompactReading.state. */
export declare const entityStateSchema: z.ZodEnum<{
    up: "up";
    degraded: "degraded";
    down: "down";
    maintenance: "maintenance";
}>;
/**
 * One-character worst-state codes for the compact day encoding.
 * The verbose object form (`{date, uptime, avgMs, worst}` × 90 × N
 * entities) measured ~29 KB for five entities — triple the ADR-005 §2
 * summary budget — so days ship as `[uptime, avgMs, worstChar]` tuples
 * anchored by a single `daysEnd` date per entity.
 */
export declare const WORST_CODES: {
    readonly u: "up";
    readonly g: "degraded";
    readonly d: "down";
    readonly m: "maintenance";
};
export type WorstCode = keyof typeof WORST_CODES;
/** Compact day tuple: [uptime 0-100, avgMs|null, worst-state code]. */
export declare const dayTupleSchema: z.ZodTuple<[z.ZodNumber, z.ZodNullable<z.ZodNumber>, z.ZodEnum<{
    u: "u";
    g: "g";
    d: "d";
    m: "m";
}>], null>;
export type DayTuple = z.infer<typeof dayTupleSchema>;
/** Decoded day rollup (ergonomic client shape — see decodeDayRollups). */
export interface DayRollup {
    date: string;
    /** Uptime percentage 0-100 */
    uptime: number;
    /** Average latency over 'up' checks; null when none (or not probed) */
    avgMs: number | null;
    /** Worst state observed that day */
    worst: (typeof WORST_CODES)[WorstCode];
}
export declare const summaryEntitySchema: z.ZodObject<{
    name: z.ZodString;
    type: z.ZodEnum<{
        system: "system";
        process: "process";
    }>;
    displayName: z.ZodOptional<z.ZodString>;
    status: z.ZodEnum<{
        up: "up";
        degraded: "degraded";
        down: "down";
        maintenance: "maintenance";
    }>;
    uptime: z.ZodObject<{
        d1: z.ZodNumber;
        d7: z.ZodNumber;
        d90: z.ZodNumber;
    }, z.core.$strip>;
    responseTimeMs: z.ZodObject<{
        d1: z.ZodNullable<z.ZodNumber>;
    }, z.core.$strip>;
    daysEnd: z.ZodString;
    days: z.ZodArray<z.ZodTuple<[z.ZodNumber, z.ZodNullable<z.ZodNumber>, z.ZodEnum<{
        u: "u";
        g: "g";
        d: "d";
        m: "m";
    }>], null>>;
}, z.core.$strip>;
export declare const incidentSchema: z.ZodObject<{
    issueNumber: z.ZodNumber;
    title: z.ZodString;
    severity: z.ZodEnum<{
        critical: "critical";
        major: "major";
        minor: "minor";
    }>;
    status: z.ZodEnum<{
        open: "open";
        resolved: "resolved";
    }>;
    entities: z.ZodArray<z.ZodString>;
    createdAt: z.ZodString;
    closedAt: z.ZodNullable<z.ZodString>;
    bodyHtml: z.ZodString;
}, z.core.$strip>;
export declare const maintenanceWindowSchema: z.ZodObject<{
    issueNumber: z.ZodNumber;
    title: z.ZodString;
    start: z.ZodString;
    end: z.ZodString;
    status: z.ZodEnum<{
        upcoming: "upcoming";
        "in-progress": "in-progress";
        completed: "completed";
    }>;
    entities: z.ZodArray<z.ZodString>;
    bodyHtml: z.ZodString;
}, z.core.$strip>;
export declare const summarySchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    generatedAt: z.ZodString;
    generatedBy: z.ZodString;
    entities: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        type: z.ZodEnum<{
            system: "system";
            process: "process";
        }>;
        displayName: z.ZodOptional<z.ZodString>;
        status: z.ZodEnum<{
            up: "up";
            degraded: "degraded";
            down: "down";
            maintenance: "maintenance";
        }>;
        uptime: z.ZodObject<{
            d1: z.ZodNumber;
            d7: z.ZodNumber;
            d90: z.ZodNumber;
        }, z.core.$strip>;
        responseTimeMs: z.ZodObject<{
            d1: z.ZodNullable<z.ZodNumber>;
        }, z.core.$strip>;
        daysEnd: z.ZodString;
        days: z.ZodArray<z.ZodTuple<[z.ZodNumber, z.ZodNullable<z.ZodNumber>, z.ZodEnum<{
            u: "u";
            g: "g";
            d: "d";
            m: "m";
        }>], null>>;
    }, z.core.$strip>>;
    incidents: z.ZodObject<{
        open: z.ZodArray<z.ZodObject<{
            issueNumber: z.ZodNumber;
            title: z.ZodString;
            severity: z.ZodEnum<{
                critical: "critical";
                major: "major";
                minor: "minor";
            }>;
            status: z.ZodEnum<{
                open: "open";
                resolved: "resolved";
            }>;
            entities: z.ZodArray<z.ZodString>;
            createdAt: z.ZodString;
            closedAt: z.ZodNullable<z.ZodString>;
            bodyHtml: z.ZodString;
        }, z.core.$strip>>;
        recent: z.ZodArray<z.ZodObject<{
            issueNumber: z.ZodNumber;
            title: z.ZodString;
            severity: z.ZodEnum<{
                critical: "critical";
                major: "major";
                minor: "minor";
            }>;
            status: z.ZodEnum<{
                open: "open";
                resolved: "resolved";
            }>;
            entities: z.ZodArray<z.ZodString>;
            createdAt: z.ZodString;
            closedAt: z.ZodNullable<z.ZodString>;
            bodyHtml: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    maintenance: z.ZodObject<{
        upcoming: z.ZodArray<z.ZodObject<{
            issueNumber: z.ZodNumber;
            title: z.ZodString;
            start: z.ZodString;
            end: z.ZodString;
            status: z.ZodEnum<{
                upcoming: "upcoming";
                "in-progress": "in-progress";
                completed: "completed";
            }>;
            entities: z.ZodArray<z.ZodString>;
            bodyHtml: z.ZodString;
        }, z.core.$strip>>;
        inProgress: z.ZodArray<z.ZodObject<{
            issueNumber: z.ZodNumber;
            title: z.ZodString;
            start: z.ZodString;
            end: z.ZodString;
            status: z.ZodEnum<{
                upcoming: "upcoming";
                "in-progress": "in-progress";
                completed: "completed";
            }>;
            entities: z.ZodArray<z.ZodString>;
            bodyHtml: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>;
}, z.core.$strip>;
/** Wire schema for one compact reading (JSONL archives, entity details). */
export declare const compactReadingSchema: z.ZodObject<{
    t: z.ZodNumber;
    svc: z.ZodString;
    state: z.ZodEnum<{
        up: "up";
        degraded: "degraded";
        down: "down";
        maintenance: "maintenance";
    }>;
    code: z.ZodNumber;
    lat: z.ZodNumber;
    err: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const entityDetailSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    generatedAt: z.ZodString;
    name: z.ZodString;
    readings: z.ZodArray<z.ZodObject<{
        t: z.ZodNumber;
        svc: z.ZodString;
        state: z.ZodEnum<{
            up: "up";
            degraded: "degraded";
            down: "down";
            maintenance: "maintenance";
        }>;
        code: z.ZodNumber;
        lat: z.ZodNumber;
        err: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const rawIncidentBodySchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    issueNumber: z.ZodNumber;
    updatedAt: z.ZodString;
    bodyMarkdown: z.ZodString;
}, z.core.$strip>;
/**
 * repository_dispatch client_payload from an external prober (ADR-005
 * §6, Worker trust model; ticket #76). The receiving Action validates
 * before ANY write — a malformed payload is rejected without touching
 * the data branch. The readings cap bounds what a compromised or
 * misconfigured dispatcher can make the ingest workflow write per event.
 */
export declare const probeDispatchPayloadSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    source: z.ZodString;
    readings: z.ZodArray<z.ZodObject<{
        t: z.ZodNumber;
        svc: z.ZodString;
        state: z.ZodEnum<{
            up: "up";
            degraded: "degraded";
            down: "down";
            maintenance: "maintenance";
        }>;
        code: z.ZodNumber;
        lat: z.ZodNumber;
        err: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type StatusSummary = z.infer<typeof summarySchema>;
export type SummaryEntity = z.infer<typeof summaryEntitySchema>;
export type StatusIncidentV1 = z.infer<typeof incidentSchema>;
export type MaintenanceWindowV1 = z.infer<typeof maintenanceWindowSchema>;
export type EntityDetail = z.infer<typeof entityDetailSchema>;
export type RawIncidentBody = z.infer<typeof rawIncidentBodySchema>;
export type ProbeDispatchPayload = z.infer<typeof probeDispatchPayloadSchema>;
/**
 * Encode decoded rollups (oldest→newest, contiguous UTC days) into the
 * compact wire form. The writer-side counterpart of decodeDayRollups.
 */
export declare function encodeDayRollups(rollups: DayRollup[]): {
    daysEnd: string;
    days: DayTuple[];
};
/**
 * Decode an entity's compact day tuples back into dated rollups by
 * walking backward from daysEnd (contiguous UTC days).
 */
export declare function decodeDayRollups(entity: Pick<SummaryEntity, 'daysEnd' | 'days'>): DayRollup[];
export declare function parseSummary(input: unknown): StatusSummary;
export declare function parseEntityDetail(input: unknown): EntityDetail;
export declare function parseRawIncidentBody(input: unknown): RawIncidentBody;
export declare function parseProbeDispatch(input: unknown): ProbeDispatchPayload;
//# sourceMappingURL=status-v1.d.ts.map