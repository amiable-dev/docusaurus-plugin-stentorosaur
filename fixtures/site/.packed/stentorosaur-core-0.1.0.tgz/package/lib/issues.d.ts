/**
 * GitHub issue payload → status/v1 transforms (ADR-005 §1: fetching is
 * I/O and lives in probe; these functions only transform already-fetched
 * payloads). Pure and client-safe — HTML rendering is INJECTED so the
 * sanitizer (jsdom-backed, server-only) never enters client bundles.
 */
import type { LabelParser, EntityRef } from './labels';
import type { StatusIncidentV1 } from './status-v1';
/** The subset of a GitHub REST issue the transforms consume. */
export interface IssuePayload {
    number: number;
    title: string;
    state: 'open' | 'closed';
    created_at: string;
    updated_at: string;
    closed_at?: string | null;
    html_url: string;
    body?: string | null;
    labels: Array<{
        name: string;
    }>;
}
export interface TransformContext {
    entities: EntityRef[];
    labelParser: LabelParser;
    /** Write-time markdown → sanitized HTML (see server-only render.ts) */
    renderHtml: (markdown: string) => string;
}
/** Severity from labels: critical > major > minor (default). */
export declare function extractSeverity(labels: string[]): 'critical' | 'major' | 'minor';
/** Whether the label set marks a scheduled-maintenance issue. */
export declare function isMaintenanceIssue(labels: string[], maintenanceLabels: string[]): boolean;
/**
 * Convert an issue into a status/v1 incident. Entity references use
 * canonical NAMES (displayName mapping is a presentation concern).
 */
export declare function issueToIncidentV1(issue: IssuePayload, ctx: TransformContext): StatusIncidentV1;
type EntityState = 'up' | 'degraded' | 'down' | 'maintenance';
/**
 * Worst-wins entity status: starts from the probe-observed state and
 * escalates for OPEN incidents affecting the entity (port of the
 * plugin's generateStatusItems ordering: down > degraded > maintenance > up).
 */
export declare function worstEntityStatus(probeState: EntityState, incidents: StatusIncidentV1[], entityName: string): EntityState;
export {};
//# sourceMappingURL=issues.d.ts.map