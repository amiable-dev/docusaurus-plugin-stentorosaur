/**
 * Pure aggregation functions extracted from the plugin's four historical
 * call sites (ADR-005 §1; epic #63 ticket #65):
 *   - loadContent() reading aggregation        (src/index.ts)
 *   - convertReadingsToSystemFiles()           (src/index.ts)
 *   - readSystemFiles() response-time fallback (src/index.ts)
 *   - StatusDataProvider / useDailySummary day rollups (client)
 *
 * Behavior is preserved exactly — the plugin's golden-file test
 * (packages/docusaurus-plugin-stentorosaur/__tests__/golden/) pins the
 * end-to-end outputs these functions must reproduce.
 */
import type { CompactReading, DayAggregate, DayLevelStatus, SystemAggregate, UptimeThresholds } from './types';
/** Group readings by system name (insertion order preserved). */
export declare function groupReadingsBySystem(readings: CompactReading[]): Map<string, CompactReading[]>;
/** Return a copy sorted most-recent-first. */
export declare function sortReadingsDesc(readings: CompactReading[]): CompactReading[];
/** Percentage of readings with state 'up' (0-100); 0 for empty input. */
export declare function calculateUptimePercent(readings: CompactReading[]): number;
/** Format an uptime percentage as e.g. "99.98%". */
export declare function formatUptimePercent(pct: number): string;
/**
 * Average latency over successful readings (state 'up' AND 2xx code),
 * rounded to the nearest ms; undefined when there are none.
 */
export declare function calculateAvgResponseTime(readings: CompactReading[]): number | undefined;
/**
 * Average of the first `take` entries' responseTime (entries are assumed
 * most-recent-first), rounded; undefined for empty input.
 */
export declare function averageRecentResponseTime(entries: Array<{
    responseTime: number;
}>, take?: number): number | undefined;
/** Full system-level aggregate over one system's readings. */
export declare function aggregateSystem(name: string, readings: CompactReading[]): SystemAggregate;
/** Day-level status from uptime percentage (ADR-004 thresholds). */
export declare function calculateStatusFromUptime(uptimePercent: number, checksTotal: number, thresholds?: UptimeThresholds): DayLevelStatus;
/** P95 latency (nearest-rank); null for empty input. */
export declare function calculateP95(latencies: number[]): number | null;
/**
 * Count up→down transitions in reading order.
 *
 * @param readings Must be in **chronological** order (oldest first).
 *   Passing unsorted readings will produce an inaccurate count.
 */
export declare function countIncidentTransitions(readings: CompactReading[]): number;
/**
 * Aggregate one day's readings for one service. 'maintenance' counts as
 * passed; latency statistics consider only 'up' readings.
 *
 * @param readings Should be in **chronological** order (oldest first) for an
 *   accurate `incidentCount`.  The function does not sort internally so that
 *   callers can avoid unnecessary copies when they already have sorted data.
 */
export declare function aggregateDayReadings(date: string, readings: CompactReading[], thresholds?: UptimeThresholds): DayAggregate;
/**
 * Group readings by UTC date (YYYY-MM-DD), optionally filtered to one
 * service (case-insensitive).
 */
export declare function groupReadingsByDate(readings: CompactReading[], serviceName?: string): Map<string, CompactReading[]>;
//# sourceMappingURL=aggregate.d.ts.map