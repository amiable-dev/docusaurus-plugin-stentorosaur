/**
 * Write-time markdown → sanitized HTML (ADR-005 §2/§7). SERVER-ONLY:
 * jsdom-backed DOMPurify must never enter client bundles — this module
 * is exported via the '@stentorosaur/core/server' subpath, not the
 * package root. Raw markdown is always retained under status/v1/raw/ so
 * a sanitizer CVE can be answered by re-rendering (stentorosaur
 * regenerate).
 *
 * The tag/attribute allowlist matches the plugin's client-side
 * utils/markdown.ts so rendered output is identical during migration.
 */
export declare function renderMarkdownToSafeHtml(markdown: string | undefined): string;
//# sourceMappingURL=render.d.ts.map