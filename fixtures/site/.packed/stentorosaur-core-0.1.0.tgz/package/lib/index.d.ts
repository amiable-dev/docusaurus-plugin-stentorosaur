/**
 * @stentorosaur/core — pure schemas and aggregation logic (ADR-005 §1).
 *
 * This package must contain NO I/O — pure functions over already-fetched
 * data only. Fetching (HTTP, GitHub API, git) belongs in
 * @stentorosaur/probe; rendering belongs in the Docusaurus plugin.
 */
export * from './types';
export * from './aggregate';
export * from './labels';
export * from './issues';
export * from './status-v1';
export * from './config';
//# sourceMappingURL=index.d.ts.map