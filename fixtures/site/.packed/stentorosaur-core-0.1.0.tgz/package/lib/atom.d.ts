/**
 * incidents.atom — machine-readable incident feed (ADR-005 §2, §11: the
 * v1.0 substitute for push notifications). Pure and deterministic; the
 * feed's updated timestamp is injected.
 */
import type { StatusIncidentV1 } from './status-v1';
export interface AtomFeedOptions {
    siteTitle: string;
    /** Absolute site URL, no trailing slash required */
    siteUrl: string;
    /** ISO timestamp for the feed's <updated> — injected, not clock-read */
    updated: string;
}
export declare function incidentsToAtom(incidents: StatusIncidentV1[], options: AtomFeedOptions): string;
//# sourceMappingURL=atom.d.ts.map