/**
 * Maintenance-issue parsing (ported from the plugin's maintenance-utils
 * in ticket #68; deterministic — `now` and reference dates are injected,
 * never read from the clock). SERVER-ONLY via '@stentorosaur/core/server'
 * (chrono-node is a write-side dependency).
 */
import type { MaintenanceWindowV1 } from './status-v1';
import type { IssuePayload, TransformContext } from './issues';
export interface MaintenanceFrontmatter {
    type?: string;
    start?: string;
    end?: string;
    systems?: string[];
}
/**
 * Parse human-friendly date strings to ISO 8601.
 * ISO passthrough, '@tomorrow 2am UTC' shorthand, relative ('+2h').
 *
 * `referenceDate` is REQUIRED: this module is chartered deterministic
 * (ADR-005 §5) — callers inject their `now`, never the system clock.
 */
export declare function parseHumanDate(dateStr: string, referenceDate: Date): string | null;
/**
 * Extract YAML-ish frontmatter from an issue body, skipping GitHub
 * issue-form headings that precede the first '---' delimiter.
 */
export declare function extractFrontmatter(body: string, referenceDate: Date): {
    frontmatter: MaintenanceFrontmatter;
    content: string;
};
/**
 * Maintenance window status from its times and issue state, evaluated
 * against an INJECTED `now` (determinism: buildSummary must be a pure
 * function of its inputs).
 */
export declare function getMaintenanceStatus(start: string, end: string, issueState: 'open' | 'closed', now: Date): MaintenanceWindowV1['status'];
export interface MaintenanceTransformContext extends TransformContext {
    now: Date;
}
/**
 * Convert a maintenance issue into a status/v1 window. Returns null when
 * the frontmatter lacks parseable start/end times (malformed tickets are
 * skipped, never fatal — the probe reports them separately).
 */
export declare function issueToMaintenanceV1(issue: IssuePayload, ctx: MaintenanceTransformContext): MaintenanceWindowV1 | null;
//# sourceMappingURL=maintenance.d.ts.map