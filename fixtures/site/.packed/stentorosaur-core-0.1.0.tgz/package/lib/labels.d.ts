/**
 * Label parsing for entity identification (ported from the plugin's
 * label-utils in ticket #68; the plugin copy is deleted at the v1.0
 * cutover, #77). Pure and client-safe.
 */
export type EntityType = 'system' | 'process' | 'project' | 'event' | 'sla' | 'custom';
export interface LabelScheme {
    separator: string;
    defaultType: EntityType;
    allowUntyped: boolean;
}
/** Minimal entity reference used by the transforms. */
export interface EntityRef {
    name: string;
    type: 'system' | 'process';
    displayName?: string;
}
export declare class LabelParser {
    private scheme;
    constructor(scheme?: Partial<LabelScheme>);
    /**
     * Parse a GitHub label into an entity type + name.
     * Namespaced ('system:api') and simple ('api', via defaultType) forms.
     */
    parseLabel(label: string): {
        type: EntityType;
        name: string;
    } | null;
    /** Extract known-entity references from a label set. */
    extractEntitiesFromLabels(labels: string[], knownEntities: Array<{
        name: string;
    }>): Array<{
        type: EntityType;
        name: string;
    }>;
}
//# sourceMappingURL=labels.d.ts.map