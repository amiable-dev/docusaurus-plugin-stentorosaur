/**
 * stentorosaur.config schema (ADR-005 §8; epic #63 ticket #74).
 *
 * ONE config consumed by the probe, the CLI, and (at the #77 cutover)
 * the plugin — replaces the entitiesSource config/monitorrc/hybrid
 * tri-state. Pure schema + defineConfig identity helper; the file
 * LOADER is I/O and lives in @stentorosaur/probe.
 */
import { z } from 'zod';
export declare const probeTargetSchema: z.ZodObject<{
    url: z.ZodString;
    method: z.ZodOptional<z.ZodEnum<{
        GET: "GET";
        POST: "POST";
        PUT: "PUT";
        PATCH: "PATCH";
        DELETE: "DELETE";
        HEAD: "HEAD";
        OPTIONS: "OPTIONS";
    }>>;
    timeout: z.ZodOptional<z.ZodNumber>;
    expectedCodes: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
    maxResponseTime: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export declare const configEntitySchema: z.ZodObject<{
    name: z.ZodString;
    type: z.ZodEnum<{
        system: "system";
        process: "process";
    }>;
    displayName: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    probe: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        method: z.ZodOptional<z.ZodEnum<{
            GET: "GET";
            POST: "POST";
            PUT: "PUT";
            PATCH: "PATCH";
            DELETE: "DELETE";
            HEAD: "HEAD";
            OPTIONS: "OPTIONS";
        }>>;
        timeout: z.ZodOptional<z.ZodNumber>;
        expectedCodes: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
        maxResponseTime: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const stentorosaurConfigSchema: z.ZodObject<{
    owner: z.ZodString;
    repo: z.ZodString;
    dataBranch: z.ZodDefault<z.ZodString>;
    entities: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        type: z.ZodEnum<{
            system: "system";
            process: "process";
        }>;
        displayName: z.ZodOptional<z.ZodString>;
        description: z.ZodOptional<z.ZodString>;
        probe: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            method: z.ZodOptional<z.ZodEnum<{
                GET: "GET";
                POST: "POST";
                PUT: "PUT";
                PATCH: "PATCH";
                DELETE: "DELETE";
                HEAD: "HEAD";
                OPTIONS: "OPTIONS";
            }>>;
            timeout: z.ZodOptional<z.ZodNumber>;
            expectedCodes: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
            maxResponseTime: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    incidents: z.ZodDefault<z.ZodObject<{
        statusLabel: z.ZodDefault<z.ZodString>;
        maintenanceLabels: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strip>>;
    site: z.ZodDefault<z.ZodObject<{
        title: z.ZodDefault<z.ZodString>;
        url: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    labelScheme: z.ZodOptional<z.ZodObject<{
        separator: z.ZodOptional<z.ZodString>;
        defaultType: z.ZodOptional<z.ZodEnum<{
            system: "system";
            process: "process";
        }>>;
        allowUntyped: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type StentorosaurConfig = z.infer<typeof stentorosaurConfigSchema>;
export type StentorosaurConfigInput = z.input<typeof stentorosaurConfigSchema>;
/** Identity helper for typed config files. */
export declare function defineConfig(config: StentorosaurConfigInput): StentorosaurConfigInput;
/** Parse + validate with actionable errors. */
export declare function parseConfig(input: unknown): StentorosaurConfig;
//# sourceMappingURL=config.d.ts.map